  function showWish() {
  document.getElementById("popup").style.display = "block";
  startConfetti();
}

const canvas = document.getElementById("confetti");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const confetti = [];

for (let i = 0; i < 200; i++) {
  confetti.push({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height - canvas.height,
    r: Math.random() * 6 + 4,
    d: Math.random() * 10 + 5,
    color: `hsl(${Math.random() * 360}, 100%, 70%)`,
    tilt: Math.random() * 10 - 5
  });
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let c of confetti) {
    ctx.beginPath();
    ctx.lineWidth = c.r / 2;
    ctx.strokeStyle = c.color;
    ctx.moveTo(c.x + c.tilt, c.y);
    ctx.lineTo(c.x + c.tilt + c.r / 2, c.y + c.r);
    ctx.stroke();
  }
  update();
}

function update() {
  for (let c of confetti) {
    c.y += Math.cos(c.d) + 1 + c.r / 2;
    c.tilt += Math.sin(c.d) * 0.5;
    
    if (c.y > canvas.height) {
      c.y = -10;
      c.x = Math.random() * canvas.width;
    }
  }
}

let animation;

function startConfetti() {
  if (animation) return;
  animation = setInterval(draw, 20);
}

window.addEventListener("resize", () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});